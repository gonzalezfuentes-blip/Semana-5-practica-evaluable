package modelo;
public class Director {
    private String nombre;
    private String apellidos;
    private boolean oscarGanado;
    public Director(String nombre, String apellidos, boolean oscarGanado){
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.oscarGanado = oscarGanado;
    }
    public String getNombre(){
        return this.nombre;
    }
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    public String getApellidos(){
        return this.apellidos;
    }
    public void setApellidos(String apellidos){
        this.apellidos = apellidos;
    }
    public boolean getOscarGanado(){
        return this.oscarGanado;
    }
    public void setOscarGanado(boolean oscarGanado){
        this.oscarGanado = oscarGanado;
    }
    public String getDirector() {
        return this.nombre + " " + this.apellidos + (this.oscarGanado ? " (Oscar)" : "");
    }
}
