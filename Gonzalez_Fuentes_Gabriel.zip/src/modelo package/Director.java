package modelo;
public class Director {
    private String nombre;
    private String apellidos;
    private boolean oscar_ganado;
    public Director(String nombre, String apellidos, boolean oscar_ganado){
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.oscar_ganado = oscar_ganado;
    }
    public String getnombre(){
        return this.nombre;
    }
    public void setnombre(String nombre){
        this.nombre = nombre;
    }
    public String getapellidos(){
        return this.apellidos;
    }
    public void setapellidos(String apellidos){
        this.apellidos = apellidos;
    }
    public boolean getoscar_ganado(){
        return this.oscar_ganado;
    }
    public void setoscar_ganado(boolean oscar_ganado){
        this.oscar_ganado = oscar_ganado;
    }
    public String getDirector() {
        return this.nombre + " " + this.apellidos + (this.oscar_ganado ? " (Oscar)" : "");
    }
}
