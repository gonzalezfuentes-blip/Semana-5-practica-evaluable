package modelo;
public class Pelicula {
    public String director;
    public String titulo;
    public int año_de_estreno;
    public int duración_en_minutos; 
    public int valoracion;
    public int tiempo_visionado;
    public Pelicula(String director, String titulo, int año_de_estreno, int duración_en_minutos, int valoración, int tiempo_visionado){
        this.director = director;
        this.titulo = titulo;
        this.año_de_estreno = año_de_estreno;
        this.duración_en_minutos = duración_en_minutos; 
        this.valoracion = valoracion;
        this.tiempo_visionado = tiempo_visionado;
    }
    public String getdirector(){
        return this.director;
    }
    public void setdirector(String director){
        this.director = director;
    }
    public String gettitulo(){
        return this.titulo;
    }
    public void settitulo(String titulo){
        this.titulo = titulo;
    }
    public int getaño_de_estreno(){
        return this.año_de_estreno;
    }
    public void setaño_de_estreno(int año_de_estreno){
        this.año_de_estreno = año_de_estreno;
    }
    public int getduración_en_minutos(){
        return this.duración_en_minutos;
    }
    public void setduración_en_minutos(int duración_en_minutos){
        this.duración_en_minutos = duración_en_minutos;
    } 
    public int getvaloración(){
        return this.valoracion;
    }
    public void setvaloración(int valoracion){
        this.valoracion = valoracion;
    }
    public int gettiempo_visionado(){
        return this.tiempo_visionado;
    }
    public void settiempo_visionado(int tiempo_visionado){
        this.tiempo_visionado = tiempo_visionado;
    }
    public String getTabla() {
        return this.titulo + " | " + this.año_de_estreno + " | " + this.duración_en_minutos + " | " + this.valoracion + " | " + this.director + " | " + this.tiempo_visionado;
    }
}
