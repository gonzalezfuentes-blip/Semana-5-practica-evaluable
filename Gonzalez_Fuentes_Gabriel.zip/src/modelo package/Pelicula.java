package modelo;
public class Pelicula {
    private Director director;
    private String titulo;
    private int ano_de_estreno;
    private int duracion_en_minutos; 
    private double valoracion;
    private int tiempo_visionado;
    
    public Pelicula(Director director, String titulo, int ano_de_estreno, int duracion_en_minutos, double valoracion, int tiempo_visionado){
        this.director = director;
        this.titulo = titulo;
        this.ano_de_estreno = ano_de_estreno;
        this.duracion_en_minutos = duracion_en_minutos; 
        this.valoracion = valoracion;
        this.tiempo_visionado = tiempo_visionado;
    }
    
    public Director getDirector(){
        return this.director;
    }
    
    public void setDirector(Director director){
        this.director = director;
    }
    
    public String getTitulo(){
        return this.titulo;
    }
    
    public void setTitulo(String titulo){
        this.titulo = titulo;
    }
    
    public int getAno_de_estreno(){
        return this.ano_de_estreno;
    }
    
    public void setAno_de_estreno(int ano_de_estreno){
        this.ano_de_estreno = ano_de_estreno;
    }
    
    public int getDuracion_en_minutos(){
        return this.duracion_en_minutos;
    }
    
    public void setDuracion_en_minutos(int duracion_en_minutos){
        this.duracion_en_minutos = duracion_en_minutos;
    } 
    
    public double getValoracion(){
        return this.valoracion;
    }
    
    public void setValoracion(double valoracion){
        this.valoracion = valoracion;
    }
    
    public int getTiempo_visionado(){
        return this.tiempo_visionado;
    }
    
    public void setTiempo_visionado(int tiempo_visionado){
        this.tiempo_visionado = tiempo_visionado;
    }
    
    public String getTabla() {
        return this.titulo + " | " + this.ano_de_estreno + " | " + this.duracion_en_minutos + " | " + this.valoracion + " | " + this.director + " | " + this.tiempo_visionado;
    }
}