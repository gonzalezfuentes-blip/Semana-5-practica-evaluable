package modelo;
public class Videoteca {
    private Pelicula[] catalogo;
    private double velocidad;
    public Videoteca(){
        this.velocidad = 1.0;
    }
    
    public double getVelocidad() {
        return velocidad; 
    }
    
    public void setVelocidad(double velocidad){
        if (velocidad <= 0){
            this.velocidad = 1.0;
        } else {
            this.velocidad = velocidad;
        }
    }
    
    public void inicializar(int longitud) {
        this.catalogo = new Pelicula[longitud];
        this.velocidad = 1.0;
        System.out.println("Videoteca inicializada. Capacidad: " + longitud);
    }
    
    public boolean agregarPelicula(Pelicula nuevaPelicula) {
        int contador;
        for (contador = 0; contador < catalogo.length; contador++) {
            if (catalogo[contador] == null) {
                catalogo[contador] = nuevaPelicula;
                return true;
            }
        }
        return false;
    }

    public void mostrarInformacion() {
        if (catalogo == null) {
            System.out.println("La videoteca no está inicializada.");
            return;
        }
        
        int cont = 0;
        for (Pelicula p : catalogo) {
            if (p != null) {
                cont++;
            }
        }
        
        if (cont == 0) {
            System.out.println("La videoteca está vacía.");
            return;
        }

        System.out.println(String.format("| %-30s | %-4s | %-5s | %-10s | %-40s |", "TÍTULO", "AÑO", "DURAC.", "VALORACIÓN", "DIRECTOR"));
        for (Pelicula p : catalogo) {
            if (p != null) {
                System.out.println(p.getTabla()); 
            }
        }
    }
}
