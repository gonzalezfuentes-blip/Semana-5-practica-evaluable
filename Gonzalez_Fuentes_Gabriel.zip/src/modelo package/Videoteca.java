package modelo;
public class Videoteca {
    public Pelicula[] catalogo;
    public double velocidad;
    public int longitud;
    private int contador;
    public Videoteca(Pelicula[] catalogo, double velocidad, int longitud, int contador){
        this.catalogo = catalogo;
        this.velocidad = velocidad;
        this.longitud = longitud;
        this.contador = contador;
    }
    public double getvelocidad() {
        return this.velocidad; 
    }
    public void setvelocidad(double velocidad) {
        this.velocidad = velocidad;
    }
    public void inicializar(int capacidad) {
        catalogo = new Pelicula[longitud];
        contador = 0;
        velocidad = 1.0;
    }
    Videoteca.setvelocidad(velocidad > 0 ? velocidad : 1.0);
    for (contador = 0; contador < longitud; contador++){
        catalogo[contador] = null;
    }
    public boolean agregarPelicula(Pelicula nuevaPelicula) {
        for (contador = 0; contador < longitud; contador++) {
            if (catalogo[i] == null) {
                catalogo[i] = nuevaPelicula;
                return true;
            }
        }
    return false;
    }

    public void informacion(){
        for (contador = 0; contador < longitud; contador++){
            if (catalogo[contador] != null){
                System.out.println(catalogo[contador].getTabla());
            }
        }
    }
}
