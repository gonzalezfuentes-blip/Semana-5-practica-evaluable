import java.util.InputMismatchException;
import java.util.Scanner;

import modelo.Director;
import modelo.Pelicula;
import modelo.Videoteca;

public class App {
    private static Videoteca videoteca = new Videoteca();
    private static Director[] director = new Director[longitud];
    private static Pelicula[] catalogo = new Pelicula[longitud]

    public static void main(Videoteca videoteca, Director[] director, Pelicula[] catalogo) {
        System.out.println("| 1) Nueva videoteca de películas              |");
        System.out.println("| 2) Configurar velocidad de reproducción      |");
        System.out.println("| 3) Añadir una nueva película a la videoteca  |");
        System.out.println("| 4) Mostrar información actual de películas   |");
        System.out.println("| 5) Salir (se borrará toda la información)    |");
        do{    
            System.out.print("Seleccione una opción (1-5): ");
            opcion = c.readInt();
        }while(opcion < 1 || opcion > 5);

        switch (opcion) {
            case 1:
                System.out.print("Introduce la capacidad de la videoteca: ");
                int longitud = c.readInt();
                videoteca.setlongitud(velocidad);
                break;
            case 2:
                System.out.print("Introduce la velocidad: ");
                double velocidad = c.readDouble();
                videoteca.setvelocidad(velocidad);
                break;
            case 3:
                anadirPelicula();
                break;
            case 4:
                videoteca.mostrarInformacion();
                muestra();
                break;
            case 5:
                System.out.println("Adios");
                break;
        }
    }
    
    private static void anadirPelicula() {
        System.out.println("Nombre del director: ");
        String nombre = c.readLine();
        director[i].setnombre(nombre);
        System.out.print("Apellidos del director: ");
        String apellidos = c.readLine();
        director[i].setapellidos(apellidos);
        System.out.print("Oscar ganado (true/false): ");
        boolean oscar_ganado = c.readBoolean();
        director[i].setoscar_ganado(oscar_ganado);

        System.out.print("Título de la película: ");
        String titulo = c.readLine();
        catalogo[i].settitulo(titulo);
        System.out.print("Año de estreno: ");
        Int año_de_estreno = c.readInt();
        catalogo[i].setaño_de_estreno(año_de_estreno);
        System.out.print("Duración en minutos: ");
        Int duración_en_minutos = c.readInt();
        catalogo[i].setduración_en_minutos(duración_en_minutos);
        System.out.print("Valoración (0.0 a 5.0): ");
        double valoracion = c.readDouble();
        catalogo[i].setvaloracion(valoracion);
        System.out.print("Tiempo visionado: ");
        int tiempo_visionado = c.readInt();
        catalogo[i].settiempo_visionado(tiempo_visionado);
    }
    private static void muestra(){
        System.out.println("Nombre del director, true/false si o no ha ganado Oscar | Titulo de pelicula | Añon de estreno | Duracion en minutos | Valoracion | Tiempo visionado");
        System.out.println(director + "|" + catalogo);
        double total_valoracion = 0;
        int total_tiempo_visionado = 0;
        for (contador = 0; contador < longitud; contador++){
            total_tiempo_visionado += catalogo[contador].tiempo_visionado;
            total_valoracion += catalogo[contador].valoracion;
        }
        System.out.println("Total de tiempo visionado es " + total_tiempo_visionado);
        System.out.println("Total de valoracion es " + total_valoracion);
    }
}
