import modelo.Director;
import modelo.Pelicula;
import modelo.Videoteca;
import java.util.Scanner;

public class App {
    private static Scanner scanner = new Scanner(System.in);
    private static Videoteca videoteca = new Videoteca();
    public static void main(String[] args) {
        int opcion;
        do {
            System.out.println("\n--- Menú de Videoteca ---");
            System.out.println("| 1) Nueva videoteca de películas              |");
            System.out.println("| 2) Configurar velocidad de reproducción      |");
            System.out.println("| 3) Añadir una nueva película a la videoteca  |");
            System.out.println("| 4) Mostrar información actual de películas   |");
            System.out.println("| 5) Salir (se borrará toda la información)    |");
            System.out.print("Seleccione una opción (1-5): ");
            if (scanner.hasNextInt()) {
                opcion = scanner.nextInt();
                scanner.nextLine(); 
            } else {
                opcion = 0;
                scanner.nextLine();
            }
            switch (opcion) {
                case 1:
                    System.out.print("Introduce la capacidad de la videoteca: ");
                    int longitud = scanner.nextInt();
                    scanner.nextLine();   
                    videoteca.inicializar(longitud);
                    break;
                case 2:
                    System.out.print("Introduce la velocidad: ");
                    double velocidad = scanner.nextDouble();
                    scanner.nextLine(); 
                    videoteca.setVelocidad(velocidad);
                    break;
                case 3:
                    anadirPelicula();
                    break;
                case 4:
                    videoteca.mostrarInformacion();
                    break;
                case 5:
                    System.out.println("Adios");
                    break;
                default:
                    System.out.println("Opción no válida.");
                    break;
            }
        } while (opcion != 5);
        scanner.close();
    }
    private static void anadirPelicula() {
        System.out.print("Nombre del director: ");
        String nombre = scanner.nextLine();
        System.out.print("Apellidos del director: ");
        String apellidos = scanner.nextLine();
        System.out.print("Oscar ganado (true/false): ");
        boolean oscarGanado;
        if (scanner.hasNextBoolean()) {
            oscarGanado = scanner.nextBoolean();
        } else {
            oscarGanado = false; 
        }
        scanner.nextLine(); 
        Director nuevoDirector = new Director(nombre, apellidos, oscarGanado);
        System.out.print("Título de la película: ");
        String titulo = scanner.nextLine();
        System.out.print("Año de estreno: ");
        int ano_de_estreno = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Duración en minutos: ");
        int duracion_en_minutos = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Valoración (0.0 a 5.0): ");
        double valoracion = scanner.nextDouble();
        scanner.nextLine();
        System.out.print("Tiempo visionado: ");
        int tiempo_visionado = scanner.nextInt();
        scanner.nextLine();
        Pelicula nuevaPelicula = new Pelicula(
            nuevoDirector, 
            titulo, 
            ano_de_estreno, 
            duracion_en_minutos, 
            valoracion, 
            tiempo_visionado
        );
        if (videoteca.agregarPelicula(nuevaPelicula)) {
            System.out.println("Película añadida con éxito.");
        } else {
            System.out.println("ERROR: La videoteca está llena o no inicializada.");
        }
    }
}
